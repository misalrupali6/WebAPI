﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace TestWebAPI_Project.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class StudentsController : ControllerBase
	{
		//[HttpGet]
		//public IActionResult GetAllStudents()
		//{
		//	var data = { "", "" };
		//	return Ok();
		//}
	}
}
