﻿using AutoMapper;

namespace TestWebAPI_Project.Mappings
{
	public class AutoMapperProfiles:Profile
	{
        public AutoMapperProfiles()
        {
            
        }
    }
}
